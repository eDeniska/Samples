//: Playground - noun: a place where people can play

import UIKit


// Варианты реализации блокировок



// @synchronized
let lockObj = NSObject()
objc_sync_enter(lockObj)
// synchronized code
objc_sync_exit(lockObj)




// старый, медленный lock
var lockRec = NSRecursiveLock()
lockRec.lock()
// synchronized code
lockRec.unlock()




// низкоуровневый mutex
var mutex = pthread_mutex_t()
pthread_mutex_lock(&mutex)
// synchronized code
pthread_mutex_unlock(&mutex)




// старый, плохой lock
var spinLock = OSSpinLock()
OSSpinLockLock(&spinLock)
// synchronized code
OSSpinLockUnlock(&spinLock)




// новый, хороший lock
var lock = os_unfair_lock()
os_unfair_lock_lock(&lock)
// synchronized code
os_unfair_lock_unlock(&lock)






// атомарные операции

var myInt:Int32 = 0

OSAtomicIncrement32(&myInt)
myInt

OSAtomicAdd32(10, &myInt)
myInt

OSAtomicCompareAndSwap32(11, 5, &myInt)
myInt
















