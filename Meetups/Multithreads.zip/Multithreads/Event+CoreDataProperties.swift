//
//  Event+CoreDataProperties.swift
//  Multithreads
//
//  Created by Данис Тазетдинов on 16.11.16.
//  Copyright © 2016 Deniska. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Event {

    @NSManaged var date: Date?
    @NSManaged var title: String?

}
