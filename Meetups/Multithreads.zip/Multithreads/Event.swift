//
//  Event.swift
//  Multithreads
//
//  Created by Данис Тазетдинов on 16.11.16.
//  Copyright © 2016 Deniska. All rights reserved.
//

import Foundation
import CoreData


class Event: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
