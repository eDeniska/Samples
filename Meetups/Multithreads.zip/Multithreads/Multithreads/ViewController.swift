//
//  ViewController.swift
//  Multithreads
//
//  Created by Данис Тазетдинов on 16.11.16.
//  Copyright © 2016 Deniska. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var labelLastEvent:UILabel!
    @IBOutlet weak var labelCounter:UILabel!
    @IBOutlet weak var progressBar:UIProgressView!

    fileprivate let lockQueue = DispatchQueue(label: "lock.queue", attributes: [])

    lazy var privateContext: NSManagedObjectContext = {
        let context = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        context.persistentStoreCoordinator = (UIApplication.shared.delegate as? AppDelegate)?.persistentStoreCoordinator
        return context
    }()

    lazy var mainContext: NSManagedObjectContext = {
        let context = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        context.persistentStoreCoordinator = (UIApplication.shared.delegate as? AppDelegate)?.persistentStoreCoordinator
        return context
    }()


    func privateContextDidSave(_ notification:Notification) {
        mainContext.perform { 
            self.mainContext.mergeChanges(fromContextDidSave: notification)
            self.updateUI()
        }
    }

    var counter:Int = 0

    func increateCounter(byValue value:Int = 1) {
        lockQueue.async { 
            self.counter += value
        }
    }

    func currentCounterValue() -> Int {
        var count:Int = 0
        lockQueue.sync {
            count = self.counter
        }
        return count
    }

    func queryCounterValue(_ completion:@escaping (Int) -> ()) {
        lockQueue.async {
            completion(self.counter)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        NotificationCenter.default.addObserver(self, selector: #selector(privateContextDidSave), name: NSNotification.Name.NSManagedObjectContextDidSave, object: privateContext)

        DispatchQueue.global(qos: .default).async {
            Thread.sleep(forTimeInterval: 5)
            //self.increateCounter()

            self.privateContext.perform {
                let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: self.privateContext) as! Event
                event.date = Date()
                event.title = "async completed"
                //self.increateCounter()
                do {
                    try self.privateContext.save()
                } catch let error {
                    print("error saving context \(error)")
                }
            }
        }

        privateContext.perform { 
            let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: self.privateContext) as! Event
            event.date = Date()
            event.title = "launched"
            do {
                try self.privateContext.save()
            } catch let error {
                print("error saving context \(error)")
            }
        }

        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(timerEvent), userInfo: nil, repeats: true)
    }

    func timerEvent(_ timer: Timer) {
        if progressBar.progress < 1.0 {
            progressBar.progress += 0.05
        } else {
            progressBar.progress = 0.0
        }
        increateCounter(byValue: 1000000)
        printCounter()
    }

    @IBAction func generateEvents() {
        privateContext.perform {
            //self.increateCounter()
            let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: self.privateContext) as! Event
            event.date = Date()
            event.title = "started generation"
            do {
                try self.privateContext.save()
            } catch {
                print("error saving context \(error)")
            }

            for _ in 0..<100000 {
                self.increateCounter()
                let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: self.privateContext) as! Event
                event.date = Date()

                event.title = "event #\(UUID().hashValue)"
            }
            do {
                try self.privateContext.save()
            } catch let error {
                print("error saving context \(error)")
            }
        }
    }
    
    @IBAction func generateMain() {
        let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: mainContext) as! Event
        event.date = Date()
        event.title = "started generation"
        do {
            try mainContext.save()
        } catch let error {
            print("error saving context \(error)")
        }
        updateUI()

        for _ in 0..<100000 {
            self.increateCounter()
            let event = NSEntityDescription.insertNewObject(forEntityName: "Event", into: mainContext) as! Event
            event.date = Date()

            event.title = "event #\(UUID().hashValue)"
        }
        do {
            try mainContext.save()
        } catch let error {
            print("error saving context \(error)")
        }
        updateUI()
    }

    func updateUI(_ async:Bool = true) {
        if (async) {
            privateContext.perform {
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Event")
                request.fetchLimit = 1
                request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
                var lastEvent:Event?
                do {
                    let events = try self.privateContext.fetch(request)
                    if events.count > 0 {
                        lastEvent = events.first as? Event
                    }

                } catch let error {
                    print("error requesting data \(error)")
                }

                DispatchQueue.main.async {
                    if let title = lastEvent?.title, let date = lastEvent?.date  {
                        self.labelLastEvent.text = "\(title) - \(date)"
                    } else {
                        self.labelLastEvent.text = "no events"
                    }
                }
            }
        } else {
            mainContext.perform {
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Event")
                request.fetchLimit = 1
                request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
                var lastEvent:Event?
                do {
                    let events = try self.mainContext.fetch(request)
                    if events.count > 0 {
                        lastEvent = events.first as? Event
                    }

                } catch let error {
                    print("error requesting data \(error)")
                }
                if let title = lastEvent?.title, let date = lastEvent?.date  {
                    self.labelLastEvent.text = "\(title) - \(date)"
                } else {
                    self.labelLastEvent.text = "no events"
                }
            }
            self.labelCounter.text = "Counter: \(self.currentCounterValue())"
        }
    }

    func printCounter(_ async:Bool = true) {
        if (async) {
            self.queryCounterValue { (count) in
                DispatchQueue.main.async {
                    self.labelCounter.text = "Counter: \(count)"
                }
            }
        } else {
            self.labelCounter.text = "Counter: \(self.currentCounterValue())"
        }
    }
}

